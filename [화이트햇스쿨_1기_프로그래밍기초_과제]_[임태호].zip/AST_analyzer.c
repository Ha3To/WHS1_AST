#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <execinfo.h>
#include <signal.h>
#include <unistd.h>

#include "/Users/limtaeho/Documents/화이트 햇/프로그래밍기초/cJSON/cJSON.h"

// 세그멘테이션 폴트를 감지하는 신호 핸들러 함수
void handler(int sig) {
    void *array[10];
    size_t size;

    // 스택의 모든 엔트리에 대한 void* 가져오기
    size = backtrace(array, 10);

    // stderr에 모든 프레임 출력
    fprintf(stderr, "에러: 신호 %d:\n", sig);
    backtrace_symbols_fd(array, size, STDERR_FILENO);
    exit(1);
}

// cJSON 배열을 받아 'If' 조건의 개수를 세는 함수
int count_if_conditions(cJSON *body) {
    if (!body || body->type != cJSON_Array) {
        return 0;
    }

    int if_count = 0;
    int array_size = cJSON_GetArraySize(body);

    for (int i = 0; i < array_size; ++i) {
        cJSON *element = cJSON_GetArrayItem(body, i);
        cJSON *node_type = cJSON_GetObjectItem(element, "_nodetype");

        if (node_type && node_type->type == cJSON_String && strcmp(node_type->valuestring, "If") == 0) {
            if_count++;
        }
    }

    return if_count;
}

// cJSON 객체로 표현된 함수를 처리하는 함수
void process_function(cJSON *function) {
    // cJSON 객체에서 정보 추출
    cJSON *name = cJSON_GetObjectItem(function, "name");
    cJSON *return_type = cJSON_GetObjectItem(function, "return_type");
    cJSON *params = cJSON_GetObjectItem(function, "params");
    cJSON *body = cJSON_GetObjectItem(function, "body");

    // 함수 이름 출력
    printf("함수 이름: %s\n", name->valuestring);

    // 반환 타입 출력, 없으면 '(none)' 출력
    if (return_type && return_type->type == cJSON_String) {
        printf("반환 타입: %s\n", return_type->valuestring);
    } else {
        printf("반환 타입: (none)\n");
    }

    // 파라미터 개수 출력
    int param_count = cJSON_GetArraySize(params);
    printf("파라미터 개수: %d\n", param_count);

    // 각 파라미터에 대한 정보 출력
    for (int i = 0; i < param_count; i++) {
        cJSON *param = cJSON_GetArrayItem(params, i);
        cJSON *param_type = cJSON_GetObjectItem(param, "type");
        cJSON *param_name = cJSON_GetObjectItem(param, "name");

        // 파라미터 타입과 이름 출력, 없으면 '(none)' 출력
        if (param_type && param_type->type == cJSON_String && param_name && param_name->type == cJSON_String) {
            printf("파라미터 %d: 타입: %s, 이름: %s\n", i + 1, param_type->valuestring, param_name->valuestring);
        } else {
            printf("파라미터 %d: 타입: (none), 이름: (none)\n", i + 1);
        }
    }

    // 함수 본문에서 'If' 조건의 개수 세고 출력
    int if_count = count_if_conditions(body);
    printf("If 조건 개수: %d\n", if_count);
}

int main() {
    // AST 데이터가 있는 JSON 파일 열기
    FILE *file = fopen("/Users/limtaeho/Documents/화이트 햇/프로그래밍기초/프로그래밍 과제/AST_Output.json", "r");
    if (!file) {
        fprintf(stderr, "JSON 파일을 열 수 없습니다.\n");
        return 1;
    }

    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    // JSON 버퍼를 위한 메모리 할당
    char *json_buffer = (char *)malloc(file_size + 1);
    if (!json_buffer) {
        fprintf(stderr, "JSON 버퍼를 위한 메모리 할당 오류.\n");
        fclose(file);
        return 1;
    }

    // JSON 파일을 버퍼로 읽기
    fread(json_buffer, 1, file_size, file);
    json_buffer[file_size] = '\0';

    // JSON을 cJSON 루트 객체로 파싱
    cJSON *root = cJSON_Parse(json_buffer);
    if (!root) {
        fprintf(stderr, "JSON 파싱 오류.\n");
        free(json_buffer);
        fclose(file);
        return 1;
    }

    // 루트 객체에서 'ext' 배열 가져오기 (함수 표현)
    cJSON *functions = cJSON_GetObjectItem(root, "ext");
    if (!functions || functions->type != cJSON_Array) {
        fprintf(stderr, "'ext' 배열을 찾을 수 없습니다.\n");
        cJSON_Delete(root);
        free(json_buffer);
        fclose(file);
        return 1;
    }

    // 함수 개수 출력
    int function_count = cJSON_GetArraySize(functions);
    printf("함수 개수: %d\n", function_count);

    // 각 함수에 대해 process_function 함수 호출하여 정보 출력
    for (int i = 0; i < function_count; ++i) {
        cJSON *function = cJSON_GetArrayItem(functions, i);
        if (function && function->type == cJSON_Object) {
            process_function(function);
        }
    }

    // 메모리 정리 및 할당 해제
    cJSON_Delete(root);
    free(json_buffer);
    fclose(file);

    // 세그멘테이션 폴트를 감지하기 위한 신호 핸들러 등록
    signal(SIGSEGV, handler);

    return 0;
}
